//This code is used to create a new Vente object, which contains information about a sale.
//The Vente object has a name, a start date, an end date, a description, the list of activities associated with the sale, and the Vente_Produit object associated with the sale.
//The Vente_Produit object contains information about the products that are sold during the sale.
//The Vente_Produit object has a list of Produit objects, which contains information about the products that are sold.
//The Produit object has a name, a price, a category, and a description.
import java.util.ArrayList;
import java.util.Date;
import com.modeliosoft.modelio.javadesigner.annotations.mdl;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

//This code is used to create a new Vente object, which contains information about a sale.
//The Vente object has a name, a start date, an end date, a description, the list of activities associated with the sale, and the Vente_Produit object associated with the sale.
//The Vente_Produit object contains information about the products that are sold during the sale.
//The Vente_Produit object has a list of Produit objects, which contains information about the products that are sold.
//The Produit object has a name, a price, a category, and a description.
@objid ("9a769da0-f0d8-4a4b-b2e8-c252e2d241da")
class Vente {
    @mdl.prop
    @objid ("8ec0c074-4fc2-48ee-8fcc-c9c8ec0bf2bb")
    private String nom;

    @mdl.prop
    @objid ("ea2beab5-320c-4296-8380-88975fd0a07c")
    private Date date_debut;

    @mdl.prop
    @objid ("883b71ea-a5b5-4e41-a651-2f6d25c71a96")
    private Date date_fin;

    @mdl.prop
    @objid ("9def39ef-37c4-488b-8dea-9da63ddbcf23")
    private String description;

    @mdl.prop
    @objid ("763137f1-d331-4e33-924f-bf6c9590ada3")
    private ArrayList<Activite> activites;

    @objid ("07f81147-850b-4e98-8637-4cb6b3904092")
     ArrayList<Vente_Produit> venteProduit;

    @objid ("254fb82f-d004-4c71-900c-125b82f7462b")
    public Vente(String nom, Date date_debut, Date date_fin, String description, ArrayList<Vente_Produit> venteProduit, ArrayList<Activite> activites) {
        if (nom == null) {
            throw new IllegalArgumentException("nom cannot be null");
        }
        if (date_debut == null) {
            throw new IllegalArgumentException("date_debut cannot be null");
        }
        if (date_fin == null) {
            throw new IllegalArgumentException("date_fin cannot be null");
        }
        if (description == null) {
            throw new IllegalArgumentException("description cannot be null");
        }
        if (activites == null) {
            throw new IllegalArgumentException("activites cannot be null");
        }
        if (venteProduit == null) {
            throw new IllegalArgumentException("venteProduit cannot be null");
        }
        this.nom = nom;
        this.date_debut = date_debut;
        this.date_fin = date_fin;
        this.description = description;
        this.activites = activites;
        this.venteProduit = venteProduit;
    }

    @objid ("7c26469f-1210-4708-90c6-31c4a9d5cf0f")
    public void setNom(String nom) {
        if (nom == null) {
            throw new IllegalArgumentException("nom cannot be null");
        }
        this.nom = nom;
    }

    @objid ("72625dc4-7480-45c5-bf47-a40933d824b3")
    public String getNom() {
        return this.nom;
    }

    @objid ("09dfdb7b-ee62-4b81-97c3-53e68c1435c9")
    public void setDate_debut(Date date_debut) {
        if (date_debut == null) {
            throw new IllegalArgumentException("date_debut cannot be null");
        }
        this.date_debut = date_debut;
    }

    @objid ("d87732fd-5094-412d-a76a-3aca7e90faea")
    public Date getDate_debut() {
        return this.date_debut;
    }

    @objid ("e158c847-de0d-4189-8fcf-1b9594e8fd3a")
    public void setDate_fin(Date date_fin) {
        if (date_fin == null) {
            throw new IllegalArgumentException("date_fin cannot be null");
        }
        this.date_fin = date_fin;
    }

    @objid ("c736bdcf-1776-4387-8b37-29f298f0ea03")
    public Date getDate_fin() {
        return this.date_fin;
    }

    @objid ("aa6f8fa1-2887-451b-ab4f-767b2706da4e")
    public void setDescription(String description) {
        if (description == null) {
            throw new IllegalArgumentException("description cannot be null");
        }
        this.description = description;
    }

    @objid ("e3ecab5e-317d-4cc3-9f2f-424730c58c1e")
    public String getDescription() {
        return this.description;
    }

    @objid ("f426469d-c109-456f-a820-57806a279960")
    public void setActivites(ArrayList<Activite> activites) {
        if (activites == null) {
            throw new IllegalArgumentException("activites cannot be null");
        }
        this.activites = activites;
    }

    @objid ("3b58fabd-26ff-4162-9a21-a2e08af81a71")
    public ArrayList<Activite> getActivites() {
        return this.activites;
    }

    @objid ("ca071549-e078-484d-963c-4a0bce5cea4f")
    public void setVenteProduit(ArrayList<Vente_Produit> venteProduit) {
        if (venteProduit == null) {
            throw new IllegalArgumentException("venteProduit cannot be null");
        }
        this.venteProduit = venteProduit;
    }

    @objid ("d35f7387-8e39-424d-9f2d-481e0fabbf48")
    public ArrayList<Vente_Produit> getVenteProduit() {
        return this.venteProduit;
    }

}
