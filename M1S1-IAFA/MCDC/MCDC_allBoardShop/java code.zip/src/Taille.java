import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("cffe8dfd-30aa-4f45-b968-9555d662a362")
enum Taille {
    ;
}
