import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("46c324dc-c712-4684-9f5e-782a1fe4471c")
class Vente_Produit {
    @objid ("fef8e6cd-bcb6-41a9-8d6f-125a75dd11a8")
    private Integer quantite;

    @objid ("45374335-ffcf-408a-a0ee-d41dd513012b")
    private Taille taille;

    @objid ("2f286076-637c-434c-89a1-956bb892587c")
    private Produit produit;

    @objid ("a6bfa686-4d25-43f2-945b-66ae6c8342cc")
    public Vente_Produit(Integer quantite, Taille taille, Produit produit) {
        this.quantite = quantite;
        this.taille = taille;
        this.produit = produit;
    }

    @objid ("e61356ee-75a4-4f8d-9606-7bc4085584be")
    public void setQuantite(Integer quantite) {
        this.quantite = quantite;
    }

    @objid ("985efd36-bfaf-43c4-bd12-e581bb52fdec")
    public Integer getQuantite() {
        return this.quantite;
    }

    @objid ("c047c242-9888-434e-bcd6-7daf81933ded")
    public void setTaille(Taille taille) {
        this.taille = taille;
    }

    @objid ("df330697-d69c-4e83-afbe-adb403dee5e8")
    public Taille getTaille() {
        return this.taille;
    }

    @objid ("b30c1c6c-d857-4c36-8011-edf6f94a48aa")
    public void setProduit(Produit produit) {
        this.produit = produit;
    }

    @objid ("a875a6fe-45c6-4a01-bb3b-780f2023b960")
    public Produit getProduit() {
        return this.produits;
    }

}
