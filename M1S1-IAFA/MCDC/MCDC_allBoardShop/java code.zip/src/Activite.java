// This enum is used to create a list of the different types of board activities
import com.modeliosoft.modelio.javadesigner.annotations.objid;

// This enum is used to create a list of the different types of board activities
@objid ("5465a07b-842a-4fb7-bb00-0cbcec0e7fd4")
enum Activite {
    SURF, // 0
    SKATE, // 1
    SNOWBOARD, // 2
    WAKEBOARD, // 3
    FUNBOARD; // 4
}
