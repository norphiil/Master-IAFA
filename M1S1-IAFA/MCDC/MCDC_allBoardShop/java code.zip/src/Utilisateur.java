import com.modeliosoft.modelio.javadesigner.annotations.mdl;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("638347f5-36ed-42a0-8fe6-0cd674b0c01d")
class Utilisateur {
    @mdl.prop
    @objid ("334febd1-4b75-4fd8-ad74-01df57aa3c35")
    private String nom;

    @mdl.prop
    @objid ("c0665540-8a51-4921-956d-027201a50416")
    private String prenom;

    @mdl.prop
    @objid ("6229b632-c30b-43a2-8204-7c8aba766976")
    private String adresse;

    @mdl.prop
    @objid ("60c854ac-5d95-4c72-a4c3-c272a5730b03")
    private String mail;

    @mdl.prop
    @objid ("3ec0a0a6-125a-47d1-ab13-46290d057286")
    private String tel;

// This constructor takes 4 arguments
    @objid ("599019e7-7d4f-4460-80bc-18e4e92fd881")
    public Utilisateur(String nom, String prenom, String adresse, String mail) {
        this(nom, prenom, adresse, mail, null);
    }

// This constructor takes 5 arguments
    @objid ("fb048038-0977-4aa5-87d3-2eb25d50c7a7")
    public Utilisateur(String nom, String prenom, String adresse, String mail, String tel) {
        if(nom == null || nom.isEmpty()){
            throw new IllegalArgumentException("Le nom ne doit pas être vide");
        }
        if(prenom == null || prenom.isEmpty()){
            throw new IllegalArgumentException("Le prénom ne doit pas être vide");
        }
        if(adresse == null || adresse.isEmpty()){
            throw new IllegalArgumentException("L'adresse ne doit pas être vide");
        }
        if(mail == null || mail.isEmpty()){
            throw new IllegalArgumentException("L'adresse mail ne doit pas être vide");
        }
        if(tel != null && !tel.matches("\\d{10}")){
            throw new IllegalArgumentException("Le numéro de téléphone doit contenir 10 chiffres");
        }
        this.nom = nom;
        this.prenom = prenom;
        this.adresse = adresse;
        this.mail = mail;
        this.tel = tel;
    }

// This is the setter for the nom property
    @objid ("52842483-7289-4b81-94f6-26638b89a49f")
    public void setNom(String nom) {
        if(nom == null || nom.isEmpty()){
            throw new IllegalArgumentException("Le nom ne doit pas être vide");
        }
        this.nom = nom;
    }

// This is the getter for the nom property
    @objid ("d88748ff-57d8-4765-8250-8b44240bac92")
    public String getNom() {
        return this.nom;
    }

// This is the setter for the prenom property
    @objid ("15ccbfdf-9512-4362-abfa-c772d72b4d1e")
    public void setPrenom(String prenom) {
        if(prenom == null || prenom.isEmpty()){
            throw new IllegalArgumentException("Le prénom ne doit pas être vide");
        }
        this.prenom = prenom;
    }

// This is the getter for the prenom property
    @objid ("da0fa72d-108d-4b4f-b21e-3b7169dc5735")
    public String getPrenom() {
        return this.prenom;
    }

// This is the setter for the adresse property
    @objid ("778161fa-f1fb-4fb6-ac18-959eba895ebd")
    public void setAdresse(String adresse) {
        if(adresse == null || adresse.isEmpty()){
            throw new IllegalArgumentException("L'adresse ne doit pas être vide");
        }
        this.adresse = adresse;
    }

// This is the getter for the adresse property
    @objid ("0b8a5cc9-c742-4020-8e27-a4002477da0f")
    public String getAdresse() {
        return this.adresse;
    }

// This is the setter for the mail property
    @objid ("a429aefe-a5a6-4ad5-aa75-e12d27158d19")
    public void setMail(String mail) {
        if(mail == null || mail.isEmpty()){
            throw new IllegalArgumentException("L'adresse mail ne doit pas être vide");
        }
        this.mail = mail;
    }

// This is the getter for the mail property
    @objid ("378e76bb-b41d-46ef-87e0-c3fccbc75187")
    public String getMail() {
        return this.mail;
    }

// This is the setter for the tel property
    @objid ("df6390ab-2723-4f83-a037-a1249d5bd27a")
    public void setTel(String tel) {
        if(tel != null && !tel.matches("\\d{10}")){
            throw new IllegalArgumentException("Le numéro de téléphone doit contenir 10 chiffres");
        }
        this.tel = tel;
    }

// This is the getter for the tel property
    @objid ("c56ff023-e600-4a95-9c73-d37b9af0a262")
    public String getTel() {
        return this.tel;
    }

}
