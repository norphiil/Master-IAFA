// This class represents a supplier.
// It is a subclass of Utilisateur (User).
import java.util.ArrayList;
import com.modeliosoft.modelio.javadesigner.annotations.mdl;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

// This class represents a supplier.
// It is a subclass of Utilisateur (User).
@objid ("63b8697d-29eb-4cdd-a60d-a3a8fffb6551")
public class Fournisseur extends Utilisateur {
    @mdl.prop
    @objid ("8988d6c2-f171-4869-8fb9-0c23b8909f70")
    private Materiel materiel;

    @mdl.prop
    @objid ("087fbe99-0bb8-44ce-a29a-2042532eec8d")
    private int quantite;

    @objid ("4f66770c-067e-426f-af4f-e5402cd2cff7")
    private ArrayList<Vente> ventes;

    @objid ("3050b4b3-e5f3-44ff-ba2d-bc0e131d49aa")
    public Fournisseur(Materiel materiel, int quantite, ArrayList<Vente> ventes) {
        if (materiel == null || quantite <= 0) {
            throw new IllegalArgumentException();
        }
        
        this.materiel = materiel;
        this.quantite = quantite;
        this.ventes = ventes;
    }

    @objid ("5ed23b23-a3f3-42e8-8206-7bf5f1e35004")
    public void setMateriel(Materiel materiel) {
        if (materiel == null) {
            throw new IllegalArgumentException();
        }
        
        this.materiel = materiel;
    }

    @objid ("31be92e6-66c1-41d3-992b-2fd00507db56")
    public Materiel getMateriel() {
        return this.materiel;
    }

    @objid ("29aff5b1-8ec0-4b51-8ba7-26cd0ab4c4c3")
    public void setQuantite(int quantite) {
        if (quantite <= 0) {
            throw new IllegalArgumentException();
        }
        
        this.quantite = quantite;
    }

    @objid ("91201e15-1965-49a2-8a8b-2533dace3819")
    public int getQuantite() {
        return this.quantite;
    }

    @objid ("b732b765-99e9-4693-be58-2b450fd27d2f")
    public void setVentes(ArrayList<Vente> ventes) {
        this.ventes = ventes;
    }

    @objid ("430ca57c-c511-4584-931b-d9c8cb93d670")
    public ArrayList<Vente> getVentes() {
        return this.ventes;
    }

}
