// This is a class that represents a product. It contains
// the name of the product and the price.
import com.modeliosoft.modelio.javadesigner.annotations.objid;

// This is a class that represents a product. It contains
// the name of the product and the price.
@objid ("1909ca08-a123-4d51-8649-3fe544af724a")
public class Produit {
    @objid ("be654545-03f6-472e-a668-7b1b45ae3788")
    private String nom;

    @objid ("ae642726-030e-4ccb-ad89-1a42cb544850")
    private String description;

    @objid ("bd39c6c6-3f3d-4445-809e-d326381c71bc")
    private String photo;

    @objid ("94a83bb0-39d6-4003-a416-0baefe505065")
    private Float prixBase;

    @objid ("19480f29-3fcf-47ba-a6ee-2ddbd6af1d60")
    private Float prixVente;

    @objid ("60bcad83-775c-484a-ab95-bf26357fbd9f")
    public Produit(String nom, String description, String photo, Float prixBase, Float prixVente) {
        this.setNom(nom);
        this.setDescription(description);
        this.setPhoto(photo);
        this.setPrixBase(prixBase);
        this.setPrixVente(prixVente);
    }

    @objid ("97e18942-3268-4fcb-b70e-2ee8c13b34d1")
    public void setNom(String nom) {
        if (nom == null) {
            throw new IllegalArgumentException("nom is null");
        }
        this.nom = nom;
    }

    @objid ("cf830840-0415-48c7-a598-011525c12612")
    public String getNom() {
        return this.nom;
    }

    @objid ("bfb4c6cb-5113-4c08-a79c-542a08619b10")
    public void setDescription(String description) {
        if (description == null) {
            throw new IllegalArgumentException("description is null");
        }
        this.description = description;
    }

    @objid ("2ed68441-5f53-45d8-9048-29af547dce01")
    public String getDescription() {
        return this.description;
    }

    @objid ("18e0b946-66cf-45f8-9bdc-654dfe599869")
    public void setPhoto(String photo) {
        if (photo == null) {
            throw new IllegalArgumentException("photo is null");
        }
        this.photo = photo;
    }

    @objid ("31543221-fdee-4b2f-84ca-892df01bdb65")
    public String getPhoto() {
        return this.photo;
    }

    @objid ("ed4793b3-6f34-4e50-8172-688c26d8cdfc")
    public void setPrixBase(Float prixBase) {
        if (prixBase == null) {
            throw new IllegalArgumentException("prixBase is null");
        }
        this.prixBase = prixBase;
    }

    @objid ("30acedef-6a42-4cb0-a941-e22b6cc68004")
    public Float getPrixBase() {
        return this.prixBase;
    }

    @objid ("bfa2fbe4-54ff-4eb1-9adf-0b78ed6c5588")
    public void setPrixVente(Float prixVente) {
        if (prixVente == null) {
            throw new IllegalArgumentException("prixVente is null");
        }
        this.prixVente = prixVente;
    }

    @objid ("c197c775-a34c-4c43-8022-3a427e800cfb")
    public Float getPrixVente() {
        return this.prixVente;
    }

}
