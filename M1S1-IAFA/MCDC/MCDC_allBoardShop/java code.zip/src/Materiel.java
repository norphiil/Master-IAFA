import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("74a3eb41-e3a7-4859-b374-8bee9c3d5c57")
enum Materiel {
    HARD_GOOD,
    SOFT_GOOD;
}
