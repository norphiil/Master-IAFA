// This code initializes the client class
// The client class inherits from the Utilisateur class
// The client class is used to store information about a client
import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.mdl;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

// This code initializes the client class
// The client class inherits from the Utilisateur class
// The client class is used to store information about a client
@objid ("6194d0c4-2d6d-4839-914d-0af944a1bff7")
public class Client extends Utilisateur {
    @mdl.prop
    @objid ("dcb14857-fdf6-43c0-8167-2c7993e0ed3a")
    private boolean privileged;

    @mdl.prop
    @objid ("b61b8750-fc80-4940-b79e-e7e4249b9971")
    private ArrayList<Activite> activities;

    @objid ("54d40ca1-a3a0-4c58-8a57-3f15a7386e22")
    private List<Vente> venteInscrit = new ArrayList<Vente> ();

    @objid ("cf0a7723-baac-4de4-91f1-59105bc7859a")
    public Client(String nom, String prenom, String adresse, String mail, ArrayList<Activite> activites) {
        this(nom, prenom, adresse, mail, null, false, activites);
    }

    @objid ("b9948ee4-0716-4747-a881-c69bd2852f8d")
    public Client(String nom, String prenom, String adresse, String mail, String tel, ArrayList<Activite> activites) {
        this(nom, prenom, adresse, mail, tel, false, activites);
    }

    @objid ("2e9ed6d2-0aef-4341-92b5-53476b5000dc")
    public Client(String nom, String prenom, String adresse, String mail, ArrayList<Activite> activites, boolean privilegie) {
        this(nom, prenom, adresse, mail, null, privilegie, activites);
    }

    @objid ("c16c9e0d-5b0f-4f5a-8d08-8f5304c2dbaf")
    public Client(String nom, String prenom, String adresse, String mail, String tel, ArrayList<Activite> activites, boolean privilegie) {
        super(nom, prenom, adresse, mail, tel);
        this.privileged = privilegie;
        this.activities = activites;
    }

    @objid ("c6b16153-d00c-4a73-afc7-9edb8a7042b5")
    public void setPrivilegie(boolean privilegie) {
        this.privileged = privilegie;
    }

    @objid ("84b74cf9-dad5-4680-98b2-412230af5860")
    public boolean getPrivilegie() {
        return this.privileged;
    }

    @objid ("3ce4d6d0-ec5d-49df-864d-898940a4b735")
    public void setActivites(ArrayList<Activite> activites) {
        this.activities = activites;
    }

    @objid ("a5045cff-846c-48f2-8856-42372bcb3a81")
    public ArrayList<Activite> getActivites() {
        return this.activities;
    }

}
